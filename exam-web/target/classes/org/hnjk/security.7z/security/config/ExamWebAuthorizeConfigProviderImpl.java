package org.hnjk.security.config;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.ExpressionUrlAuthorizationConfigurer;
import org.springframework.stereotype.Component;

@Component
public class ExamWebAuthorizeConfigProviderImpl implements AuthorizeConfigProvider {

	@Override
	public void config(ExpressionUrlAuthorizationConfigurer<HttpSecurity>.ExpressionInterceptUrlRegistry config) {
		config.antMatchers("/exam/**").authenticated()
			  .antMatchers("/test","/js/**","/images/**","/css/**","/favicon.ico").permitAll();
	}

}
